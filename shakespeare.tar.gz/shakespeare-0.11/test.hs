import Test.Hspec.Monadic
import ShakespeareBaseTest (specs)

main :: IO ()
main = hspecX $ specs
